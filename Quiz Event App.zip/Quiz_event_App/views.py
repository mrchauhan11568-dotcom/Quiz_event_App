# Quiz_event_App/views.py

from django.shortcuts import render

def home_view(request):
    """Simple view to render the project home page."""
    # Renders the home.html template located in the project-level 'template' folder
    return render(request, 'home.html')