"""
URL configuration for Quiz_event_App project.
"""
from django.contrib import admin
from django.urls import path, include
from django.contrib.auth import views as auth_views # <-- Imported Django auth views
from . import views 

urlpatterns = [
    # Admin route
    path('admin/', admin.site.urls),
    
    # AUTHENTICATION: Using specific views with custom template_name to fix TemplateDoesNotExist error
    path('accounts/login/', auth_views.LoginView.as_view(template_name='login.html'), name='login'),
    path('accounts/logout/', auth_views.LogoutView.as_view(next_page='/'), name='logout'),
    
    # Home Page 
    path('', views.home_view, name='home'),
    
    # Quiz App URLs (Links to quiz_app/urls.py)
    path('quizzes/', include('quiz_app.urls')),
    
    # Event App URLs (Links to event_app/urls.py)
    path('events/', include('event_app.urls')),
    
    # Optional: Django Browser Reload (if you use it)
    # Note: Ensure 'django_browser_reload' is installed and in INSTALLED_APPS
    path("__reload__/", include("django_browser_reload.urls")),
]