from django.shortcuts import render
from .models import Event # Import the Event model
from django.utils import timezone # Import timezone for potential filtering

def event_list_view(request):
    # Fetch all Event objects, maybe ordered by date (optional: filter for future events)
    events = Event.objects.all().order_by('date')
    
    context = {'events': events}
    return render(request, 'event_app/event_list.html', context)