from django.db import models

class Quiz(models.Model):
    # Core Quiz structure
    title = models.CharField(max_length=200)
    description = models.TextField(blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return self.title

class Question(models.Model):
    # Links to the Quiz it belongs to
    quiz = models.ForeignKey(Quiz, on_delete=models.CASCADE, related_name='questions')
    text = models.TextField()
    # 'question_type' can be used later (optional for now, but good practice)
    question_type = models.CharField(
        max_length=50, 
        choices=[('MC', 'Multiple Choice')], 
        default='MC'
    )
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"Q: {self.text[:50]}..."
    
class Answer(models.Model):
    # Links to the Question it is an answer for
    question = models.ForeignKey(Question, on_delete=models.CASCADE, related_name='answers')
    text = models.CharField(max_length=255)
    is_correct = models.BooleanField(default=False)

    def __str__(self):
        return f"A: {self.text[:50]} ({'Correct' if self.is_correct else 'Incorrect'})"

# --- Models for tracking user attempts (Submission Logic) ---

class UserSubmission(models.Model):
    # Tracks the overall attempt
    quiz = models.ForeignKey(Quiz, on_delete=models.CASCADE)
    user_name = models.CharField(max_length=100) # Since authentication is optional
    score = models.IntegerField(default=0)
    submitted_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.user_name}'s submission for {self.quiz.title}"

class UserAnswer(models.Model):
    # Tracks the user's answer to each question in a submission
    submission = models.ForeignKey(UserSubmission, on_delete=models.CASCADE, related_name='user_answers')
    question = models.ForeignKey(Question, on_delete=models.CASCADE)
    # Storing the chosen answer. We could also link to the Answer model if needed.
    # For simplicity, we track the text of the chosen answer or its ID. Let's use ID for a proper relationship.
    chosen_answer = models.ForeignKey(Answer, on_delete=models.CASCADE, null=True, blank=True)
    
    # Store the result for easy access later
    is_correct = models.BooleanField(default=False) 

    def __str__(self):
        return f"Q: {self.question.text[:20]}... - Correct: {self.is_correct}"


class Event(models.Model):
    # Model fields based on PDF: id, title, description, date, location
    title = models.CharField(max_length=200)
    description = models.TextField()
    date = models.DateTimeField() # Use DateTimeField for date and time
    location = models.CharField(max_length=200)

    def __str__(self):
        # A human-readable representation of the object
        return f"{self.title} on {self.date.strftime('%Y-%m-%d')}"