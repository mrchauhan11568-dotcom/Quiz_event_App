from django.urls import path
from . import views

urlpatterns = [
    # Path: /events/
    path('', views.event_list_view, name='event_list'),
]