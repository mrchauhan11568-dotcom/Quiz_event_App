# quiz_app/urls.py

from django.urls import path
from . import views

urlpatterns = [
    # Path: /quizzes/
    path('', views.quiz_list_view, name='quiz_list'),
    
    # Path: /quizzes/history/  (BONUS FEATURE)
    path('history/', views.quiz_history_view, name='quiz_history'), 
    
    # Path: /quizzes/1/start/ 
    path('<int:pk>/start/', views.quiz_start_view, name='quiz_start'), 
    
    # Path: /quizzes/1/submit/ 
    path('<int:pk>/submit/', views.quiz_submit_view, name='quiz_submit'),
    
    # Path: /quizzes/result/1/
    path('result/<int:submission_pk>/', views.quiz_result_view, name='quiz_result'),
]