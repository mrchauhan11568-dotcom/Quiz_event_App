from django.shortcuts import render, get_object_or_404, redirect
from django.db import transaction
from django.contrib.auth.decorators import login_required
from .models import Quiz, Question, Answer, UserSubmission, UserAnswer

# --- 1. Quiz List View ---
def quiz_list_view(request):
    """Fetches and displays all available quizzes."""
    quizzes = Quiz.objects.all()
    context = {'quizzes': quizzes}
    return render(request, 'quiz_app/quiz_list.html', context)

# --- 2. Quiz Start View ---
def quiz_start_view(request, pk):
    """Displays the form with all questions and answers for a given Quiz."""
    quiz = get_object_or_404(Quiz, pk=pk)
    questions = quiz.questions.all().prefetch_related('answers')
    
    context = {
        'quiz': quiz,
        'questions': questions,
    }
    return render(request, 'quiz_app/quiz_attempt.html', context)

# --- 3. Quiz Submission View (Core Logic) ---
@transaction.atomic
def quiz_submit_view(request, pk):
    """Processes the submitted quiz, calculates score, and saves submission details."""
    if request.method == 'POST':
        quiz = get_object_or_404(Quiz, pk=pk)
        
        # 1. Get User Data
        user_name = request.POST.get('user_name', 'Anonymous')
        score = 0
        
        # Determine User (Django User if authenticated, otherwise None)
        submission_user = request.user if request.user.is_authenticated else None
        
        # 2. Create the User Submission Record
        submission = UserSubmission.objects.create(
            quiz=quiz,
            user=submission_user,
            user_name=user_name,
            score=0
        )
        
        questions = quiz.questions.all()
        
        # 3. Process each Question and Score
        for question in questions:
            submitted_answer_pk = request.POST.get(f'question_{question.pk}')
            
            try:
                chosen_answer = Answer.objects.get(pk=submitted_answer_pk)
            except Answer.DoesNotExist:
                continue 

            is_correct = chosen_answer.is_correct
            
            if is_correct:
                score += 1
            
            # 4. Save the User Answer Record
            UserAnswer.objects.create(
                submission=submission,
                question=question,
                chosen_answer=chosen_answer,
                is_correct=is_correct,
            )

        # 5. Update and Save Final Score on Submission Record
        submission.score = score
        submission.save()
        
        # 6. Redirect to Results Page
        return redirect('quiz_result', submission_pk=submission.pk)

    return redirect('quiz_start', pk=pk)

# --- 4. Quiz Result View ---
def quiz_result_view(request, submission_pk):
    """Displays the score and detailed feedback for a user submission."""
    
    submission = get_object_or_404(
        UserSubmission.objects.prefetch_related('user_answers__question__answers', 
                                                'user_answers__chosen_answer'), 
        pk=submission_pk
    )

    # Add correct answer object to each user_answer (safe for template)
    for ua in submission.user_answers.all():
        ua.correct_answer = next(
            (ans for ans in ua.question.answers.all() if ans.is_correct),
            None
        )
    
    total_questions = submission.quiz.questions.count()
    percentage = (submission.score / total_questions) * 100 if total_questions else 0
    
    context = {
        'submission': submission,
        'total_questions': total_questions,
        'percentage': round(percentage, 2),
    }
    return render(request, 'quiz_app/quiz_result.html', context)

# --- 5. Quiz History View (Bonus) ---
@login_required
def quiz_history_view(request):
    """Displays the submission history for the currently logged-in user."""
    
    history = UserSubmission.objects.filter(user=request.user).order_by('-submitted_at')
    
    context = {
        'history': history
    }
    return render(request, 'quiz_app/quiz_history.html', context)
