from django.contrib import admin
from .models import Quiz, Question, Answer, UserSubmission, UserAnswer


class AnswerInline(admin.TabularInline):
    """Allows answers to be added directly on the Question admin page."""
    model = Answer
    extra = 4 

class QuestionAdmin(admin.ModelAdmin):
    """Admin view for Question, showing Answers underneath."""
    inlines = [AnswerInline]
    list_display = ('text', 'quiz', 'created_at')
    list_filter = ('quiz',)

class QuestionInline(admin.TabularInline):
    """Allows questions to be added directly on the Quiz admin page."""
    model = Question
    extra = 1

class QuizAdmin(admin.ModelAdmin):
    """Admin view for Quiz, showing Questions underneath."""
    inlines = [QuestionInline]
    list_display = ('title', 'created_at')

admin.site.register(Quiz, QuizAdmin)
admin.site.register(Question, QuestionAdmin)
admin.site.register(Answer)
admin.site.register(UserSubmission)
admin.site.register(UserAnswer)