from django.db import models
from django.contrib.auth.models import User # <-- NEW: Import the User model

class Quiz(models.Model):
    # Core Quiz structure
    title = models.CharField(max_length=200)
    description = models.TextField(blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return self.title

class Question(models.Model):
    # Links to the Quiz it belongs to
    quiz = models.ForeignKey(Quiz, on_delete=models.CASCADE, related_name='questions')
    text = models.TextField()
    question_type = models.CharField(
        max_length=50, 
        choices=[('MC', 'Multiple Choice')], 
        default='MC'
    )
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"Q: {self.text[:50]}..."
    
class Answer(models.Model):
    # Links to the Question it is an answer for
    question = models.ForeignKey(Question, on_delete=models.CASCADE, related_name='answers')
    text = models.CharField(max_length=255)
    is_correct = models.BooleanField(default=False)

    def __str__(self):
        return f"A: {self.text[:50]} ({'Correct' if self.is_correct else 'Incorrect'})"

# --- Models for tracking user attempts (Submission Logic) ---

class UserSubmission(models.Model):
    # Tracks the overall attempt
    quiz = models.ForeignKey(Quiz, on_delete=models.CASCADE)
    user = models.ForeignKey(User, on_delete=models.CASCADE, null=True, blank=True) # <-- UPDATED: Link to Django User
    user_name = models.CharField(max_length=100, default='Anonymous') 
    score = models.IntegerField(default=0)
    submitted_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.user.username if self.user else self.user_name}'s submission for {self.quiz.title}"

class UserAnswer(models.Model):
    # Tracks the user's answer to each question in a submission
    submission = models.ForeignKey(UserSubmission, on_delete=models.CASCADE, related_name='user_answers')
    question = models.ForeignKey(Question, on_delete=models.CASCADE)
    chosen_answer = models.ForeignKey(Answer, on_delete=models.CASCADE, null=True, blank=True)
    is_correct = models.BooleanField(default=False) 

    def __str__(self):
        return f"Q: {self.question.text[:20]}... - Correct: {self.is_correct}"